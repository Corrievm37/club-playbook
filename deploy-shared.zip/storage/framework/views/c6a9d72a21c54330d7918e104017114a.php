<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <?php if(session('status')): ?>
        <div class="bg-green-100 text-green-800 p-3 mb-4 rounded"><?php echo e(session('status')); ?></div>
    <?php endif; ?>

    <div class="flex items-center justify-between mb-4">
        <h1 class="text-2xl font-semibold">Invoice <?php echo e($invoice->number); ?></h1>
        <div class="space-x-2">
            <a href="<?php echo e(route('invoices.pdf', $invoice->id)); ?>" class="bg-green-700 text-white px-4 py-2 rounded">Download PDF</a>
            <form method="POST" action="<?php echo e(route('admin.invoices.destroy', $invoice->id)); ?>" class="inline" onsubmit="return confirm('Delete invoice?');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="bg-red-600 text-white px-4 py-2 rounded">Delete</button>
            </form>
        </div>

    <?php if($invoice->proof_path): ?>
    <div class="bg-white border rounded p-4 mb-6">
        <h3 class="text-lg font-semibold mb-2">Submitted Proof of Payment</h3>
        <p class="mb-2">A proof of payment was uploaded on <?php echo e(optional($invoice->proof_uploaded_at)->format('Y-m-d H:i') ?? 'N/A'); ?>.</p>
        <a href="<?php echo e(asset('storage/'.$invoice->proof_path)); ?>" target="_blank" class="text-blue-700 underline">View Proof</a>
        <?php if(in_array($invoice->status, ['pending','sent','overdue','partial'])): ?>
            <form method="POST" action="<?php echo e(route('admin.invoices.confirm_proof', $invoice->id)); ?>" class="mt-3" onsubmit="return confirm('Confirm payment and mark invoice as paid?');">
                <?php echo csrf_field(); ?>
                <button class="bg-indigo-600 text-white px-4 py-2 rounded">Confirm Payment</button>
            </form>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
            <div><strong>Player:</strong> <?php echo e(optional($invoice->player)->first_name); ?> <?php echo e(optional($invoice->player)->last_name); ?></div>
            <div><strong>Fee:</strong> <?php echo e(optional($invoice->fee)->name); ?></div>
            <div><strong>Issue:</strong> <?php echo e($invoice->issue_date); ?> | <strong>Due:</strong> <?php echo e($invoice->due_date); ?></div>
            <div></div>
        </div>
        <div class="text-right">
            <div><strong>Total:</strong> ZAR <?php echo e(number_format($invoice->total_cents/100, 2)); ?></div>
            <?php ($paidCents = (int) ($invoice->payments?->sum('amount_cents') ?? 0)); ?>
            <?php (
                $badge = (function() use ($invoice, $paidCents){
                    if ($invoice->status === 'paid') return ['PAID','bg-green-100 text-green-800'];
                    if ($paidCents > 0 && (int)$invoice->balance_cents > 0) return ['PARTIALLY PAID','bg-yellow-100 text-yellow-800'];
                    if ($invoice->status === 'overdue') return ['OVERDUE','bg-red-100 text-red-800'];
                    return [strtoupper($invoice->status),'bg-gray-100 text-gray-800'];
                })()
            ); ?>
            <div><strong>Paid to date:</strong> ZAR <?php echo e(number_format($paidCents/100, 2)); ?></div>
            <div><strong>Balance:</strong> ZAR <?php echo e(number_format($invoice->balance_cents/100, 2)); ?></div>
            <div><strong>Status:</strong> <span class="inline-block px-2 py-0.5 rounded <?php echo e($badge[1]); ?>"><?php echo e($badge[0]); ?></span></div>
        </div>
    </div>

    <h2 class="text-xl font-semibold mb-2">Payments</h2>
    <div class="overflow-x-auto mb-4">
        <table class="min-w-full border">
            <thead>
                <tr class="bg-gray-100">
                    <th class="p-2 border">Date</th>
                    <th class="p-2 border">Method</th>
                    <th class="p-2 border text-right">Amount</th>
                    <th class="p-2 border">Reference</th>
                    <th class="p-2 border">Received By</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $invoice->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="p-2 border"><?php echo e($p->paid_at); ?></td>
                    <td class="p-2 border"><?php echo e(strtoupper($p->method)); ?></td>
                    <td class="p-2 border text-right"><?php echo e(number_format($p->amount_cents/100, 2)); ?></td>
                    <td class="p-2 border"><?php echo e($p->reference); ?></td>
                    <td class="p-2 border">
                        <?php ($receiver = is_numeric($p->received_by) ? optional(\App\Models\User::find($p->received_by))->name : $p->received_by); ?>
                        <?php echo e($receiver); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td class="p-4 text-center" colspan="5">No payments yet.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <h3 class="text-lg font-semibold mb-2">Capture Payment</h3>
    <form method="POST" action="<?php echo e(route('admin.invoices.payments.store', $invoice->id)); ?>" class="grid grid-cols-1 md:grid-cols-6 gap-4">
        <?php echo csrf_field(); ?>
        <div>
            <label class="block text-sm font-medium">Method</label>
            <select name="method" class="mt-1 w-full border rounded p-2">
                <option value="eft">EFT</option>
                <option value="cash">Cash</option>
                <option value="other">Other</option>
            </select>
            <?php $__errorArgs = ['method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label class="block text-sm font-medium">Amount (ZAR)</label>
            <input type="number" name="amount" step="0.01" min="0.01" class="mt-1 w-full border rounded p-2" required />
            <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label class="block text-sm font-medium">Paid At</label>
            <input type="date" name="paid_at" value="<?php echo e(now()->format('Y-m-d')); ?>" class="mt-1 w-full border rounded p-2" required />
            <?php $__errorArgs = ['paid_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label class="block text-sm font-medium">Reference</label>
            <input type="text" name="reference" class="mt-1 w-full border rounded p-2" />
            <?php $__errorArgs = ['reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="md:col-span-6">
            <label class="block text-sm font-medium">Note</label>
            <textarea name="note" class="mt-1 w-full border rounded p-2"></textarea>
            <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="md:col-span-6 flex items-center space-x-2">
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Capture</button>
            <button type="button" class="px-3 py-2 rounded border" onclick="(function(){const i=document.querySelector('input[name=amount]'); if(i){ i.value='<?php echo e(number_format($invoice->balance_cents/100, 2, '.', '')); ?>'; }})();">Pay Full Balance</button>
            <a href="<?php echo e(route('admin.invoices.index')); ?>" class="ml-2">Back</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/corneliusvanmollendorf/CascadeProjects/windsurf-project/resources/views/admin/invoices/show.blade.php ENDPATH**/ ?>