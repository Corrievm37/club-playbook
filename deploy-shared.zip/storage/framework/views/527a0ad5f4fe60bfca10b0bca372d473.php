<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto p-6 max-w-4xl">
        <?php if(session('status')): ?>
            <div class="bg-green-100 text-green-800 p-3 mb-4 rounded"><?php echo e(session('status')); ?></div>
        <?php endif; ?>
        <div class="flex items-center justify-between mb-4">
            <h1 class="text-2xl font-semibold">My Children</h1>
            <a href="<?php echo e(route('guardian.children.create')); ?>" class="inline-flex items-center bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">
                Add Child
            </a>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full border">
                <thead>
                <tr class="bg-gray-100">
                    <th class="p-2 border text-left">Name</th>
                    <th class="p-2 border text-left">DOB</th>
                    <th class="p-2 border text-left">School</th>
                    <th class="p-2 border text-left">Documents</th>
                    <th class="p-2 border">Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="p-2 border"><?php echo e($p->last_name); ?>, <?php echo e($p->first_name); ?></td>
                        <td class="p-2 border"><?php echo e($p->dob ?? '—'); ?></td>
                        <td class="p-2 border"><?php echo e($p->school_name ?? '—'); ?></td>
                        <td class="p-2 border space-x-2">
                            <?php if(!empty($p->id_document_path)): ?>
                                <a href="<?php echo e(asset('storage/'.$p->id_document_path)); ?>" target="_blank" class="text-blue-700 underline">ID Doc</a>
                            <?php endif; ?>
                            <?php if(!empty($p->medical_aid_card_path)): ?>
                                <a href="<?php echo e(asset('storage/'.$p->medical_aid_card_path)); ?>" target="_blank" class="text-blue-700 underline">Medical Card</a>
                            <?php endif; ?>
                            <?php if(empty($p->id_document_path) && empty($p->medical_aid_card_path)): ?>
                                <span class="text-gray-400">—</span>
                            <?php endif; ?>
                        </td>
                        <td class="p-2 border text-center">
                            <a href="<?php echo e(route('guardian.children.edit', $p->id)); ?>" class="text-blue-700 underline">View / Update</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="p-4 text-center">No linked children found.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/corneliusvanmollendorf/CascadeProjects/windsurf-project/resources/views/guardian/children/index.blade.php ENDPATH**/ ?>