<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto p-6">
        <?php if(session('status')): ?>
            <div class="bg-green-100 text-green-800 p-3 mb-4 rounded"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <div class="flex items-center justify-between mb-4">
            <h1 class="text-2xl font-semibold"><?php echo e(ucfirst($session->type)); ?> Register — <?php echo e($session->age_group); ?> — <?php echo e($session->scheduled_at->format('Y-m-d H:i')); ?></h1>
            <div class="space-x-3">
                <?php if($session->type === 'game'): ?>
                    <a href="<?php echo e(route('admin.attendance.assign', $session->id)); ?>" class="bg-indigo-600 text-white px-3 py-2 rounded">Assign Teams</a>
                    <a href="<?php echo e(route('admin.attendance.print', $session->id)); ?>" target="_blank" class="bg-gray-700 text-white px-3 py-2 rounded">Print Team Sheet</a>
                <?php endif; ?>
                <a href="<?php echo e(route('admin.attendance.index')); ?>" class="text-blue-700 underline">Back to Sessions</a>
            </div>
        </div>

        <div class="mb-4 text-sm text-gray-700">
            <div><strong>Title:</strong> <?php echo e($session->title ?? '—'); ?></div>
            <div><strong>Location:</strong> <?php echo e($session->location ?? '—'); ?></div>
            <div><strong>Notes:</strong> <?php echo e($session->notes ?? '—'); ?></div>
        </div>

        <?php if($session->type === 'game'): ?>
            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mt-6">
                <div class="flex items-center justify-between mb-2">
                    <h2 class="text-lg font-semibold">Team: <?php echo e($team->name); ?></h2>
                    <a href="<?php echo e(route('admin.attendance.team.print', [$session->id, $team->id])); ?>" target="_blank" class="text-sm bg-gray-700 text-white px-3 py-1 rounded">Print</a>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full border">
                        <thead>
                            <tr class="bg-gray-100">
                                <th class="p-2 border text-left">Player</th>
                                <th class="p-2 border text-left">RSVP</th>
                                <th class="p-2 border text-left">Present</th>
                                <th class="p-2 border text-left">Jersey #</th>
                                <th class="p-2 border">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $hasRows = false; ?>
                            <?php $__currentLoopData = $session->records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $a = $assignments[$rec->player->id] ?? null; ?>
                                <?php if($a && $a->team_id === $team->id): ?>
                                    <?php $hasRows = true; ?>
                                    <tr>
                                        <td class="p-2 border"><?php echo e($rec->player->last_name); ?>, <?php echo e($rec->player->first_name); ?></td>
                                        <td class="p-2 border">
                                            <form method="POST" action="<?php echo e(route('admin.attendance.rsvp.update', [$session->id, $rec->id])); ?>" class="inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <select name="rsvp_status" class="border rounded p-1 text-sm">
                                                    <?php $__currentLoopData = ['unknown'=>'Unknown','yes'=>'Yes','no'=>'No','maybe'=>'Maybe']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($val); ?>" <?php echo e($rec->rsvp_status===$val?'selected':''); ?>><?php echo e($label); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <button class="ml-2 px-2 py-1 text-xs bg-blue-600 text-white rounded">Save</button>
                                            </form>
                                        </td>
                                        <td class="p-2 border">
                                            <form method="POST" action="<?php echo e(route('admin.attendance.presence.update', [$session->id, $rec->id])); ?>" class="inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <input type="hidden" name="present" value="0" />
                                                <label class="inline-flex items-center space-x-2">
                                                    <input type="checkbox" name="present" value="1" <?php echo e($rec->present ? 'checked' : ''); ?> onchange="this.form.submit()" />
                                                    <span>Present</span>
                                                </label>
                                            </form>
                                        </td>
                                        <td class="p-2 border"><?php echo e($a && $a->jersey_number ? $a->jersey_number : '—'); ?></td>
                                        <td class="p-2 border text-center">
                                            <span class="text-gray-400">—</span>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!$hasRows): ?>
                                <tr>
                                    <td colspan="5" class="p-4 text-center">No players assigned to this team.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="mt-8">
                <h2 class="text-lg font-semibold mb-2">Unassigned</h2>
                <div class="overflow-x-auto">
                    <table class="min-w-full border">
                        <thead>
                            <tr class="bg-gray-100">
                                <th class="p-2 border text-left">Player</th>
                                <th class="p-2 border text-left">RSVP</th>
                                <th class="p-2 border text-left">Present</th>
                                <th class="p-2 border">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $hasUnassigned = false; ?>
                            <?php $__currentLoopData = $session->records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $a = $assignments[$rec->player->id] ?? null; ?>
                                <?php if(!$a || !$a->team_id): ?>
                                    <?php $hasUnassigned = true; ?>
                                    <tr>
                                        <td class="p-2 border"><?php echo e($rec->player->last_name); ?>, <?php echo e($rec->player->first_name); ?></td>
                                        <td class="p-2 border">
                                            <form method="POST" action="<?php echo e(route('admin.attendance.rsvp.update', [$session->id, $rec->id])); ?>" class="inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <select name="rsvp_status" class="border rounded p-1 text-sm">
                                                    <?php $__currentLoopData = ['unknown'=>'Unknown','yes'=>'Yes','no'=>'No','maybe'=>'Maybe']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($val); ?>" <?php echo e($rec->rsvp_status===$val?'selected':''); ?>><?php echo e($label); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <button class="ml-2 px-2 py-1 text-xs bg-blue-600 text-white rounded">Save</button>
                                            </form>
                                        </td>
                                        <td class="p-2 border">
                                            <form method="POST" action="<?php echo e(route('admin.attendance.presence.update', [$session->id, $rec->id])); ?>" class="inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <input type="hidden" name="present" value="0" />
                                                <label class="inline-flex items-center space-x-2">
                                                    <input type="checkbox" name="present" value="1" <?php echo e($rec->present ? 'checked' : ''); ?> onchange="this.form.submit()" />
                                                    <span>Present</span>
                                                </label>
                                            </form>
                                        </td>
                                        <td class="p-2 border text-center"><span class="text-gray-400">—</span></td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!$hasUnassigned): ?>
                                <tr>
                                    <td colspan="4" class="p-4 text-center">No unassigned players.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="min-w-full border">
                    <thead>
                        <tr class="bg-gray-100">
                            <th class="p-2 border text-left">Player</th>
                            <th class="p-2 border text-left">RSVP</th>
                            <th class="p-2 border text-left">Present</th>
                            <th class="p-2 border">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $session->records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="p-2 border"><?php echo e($rec->player->last_name); ?>, <?php echo e($rec->player->first_name); ?></td>
                            <td class="p-2 border">
                                <form method="POST" action="<?php echo e(route('admin.attendance.rsvp.update', [$session->id, $rec->id])); ?>" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <select name="rsvp_status" class="border rounded p-1 text-sm">
                                        <?php $__currentLoopData = ['unknown'=>'Unknown','yes'=>'Yes','no'=>'No','maybe'=>'Maybe']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($val); ?>" <?php echo e($rec->rsvp_status===$val?'selected':''); ?>><?php echo e($label); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button class="ml-2 px-2 py-1 text-xs bg-blue-600 text-white rounded">Save</button>
                                </form>
                            </td>
                            <td class="p-2 border">
                                <form method="POST" action="<?php echo e(route('admin.attendance.presence.update', [$session->id, $rec->id])); ?>" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="present" value="0" />
                                    <label class="inline-flex items-center space-x-2">
                                        <input type="checkbox" name="present" value="1" <?php echo e($rec->present ? 'checked' : ''); ?> onchange="this.form.submit()" />
                                        <span>Present</span>
                                    </label>
                                </form>
                            </td>
                            <td class="p-2 border text-center"><span class="text-gray-400">—</span></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="p-4 text-center">No players found for this age group.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/corneliusvanmollendorf/CascadeProjects/windsurf-project/resources/views/admin/attendance/show.blade.php ENDPATH**/ ?>