<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <link rel="icon" type="image/png" href="<?php echo e(asset('images/logo.png')); ?>">
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>">

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <style>[x-cloak]{display:none !important;}</style>
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100">
            <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- Page Heading -->
            <?php if(isset($header)): ?>
                <header class="bg-white shadow">
                    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                        <?php echo e($header); ?>

                    </div>
                </header>
            <?php endif; ?>

            <!-- Page Content -->
            <main class="pb-16">
                <?php if(isset($slot)): ?>
                    <?php echo e($slot); ?>

                <?php else: ?>
                    <?php echo $__env->yieldContent('content'); ?>
                <?php endif; ?>
            </main>
        </div>

        <?php
            $activeClubId = session('active_club_id');
            $footerClub = $activeClubId ? \App\Models\Club::find($activeClubId) : null;
        ?>
        <?php if($footerClub && $footerClub->logo_url): ?>
            <div class="fixed bottom-0 inset-x-0 bg-white/80 backdrop-blur border-t border-gray-200 py-2 z-40">
                <div class="max-w-7xl mx-auto px-4 grid grid-cols-3 items-center">
                    <?php if(auth()->guard()->check()): ?>
                        <?php
                            $memberships = \App\Models\Membership::with('club')->where('user_id', Auth::id())->get();
                        ?>
                        <?php if($memberships->count() > 0): ?>
                            <form method="POST" action="<?php echo e(route('admin.active-club.set')); ?>" class="justify-self-start">
                                <?php echo csrf_field(); ?>
                                <label class="text-xs text-gray-600 mr-2">Active Club</label>
                                <select name="club_id" class="border rounded p-1 text-xs" onchange="this.form.submit()">
                                    <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($m->club->id); ?>" <?php echo e((int)$activeClubId === (int)$m->club->id ? 'selected' : ''); ?>><?php echo e($m->club->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </form>
                        <?php endif; ?>
                    <?php endif; ?>
                    <div class="justify-self-center">
                        <div class="bg-white/90 rounded-full shadow ring-1 ring-gray-200 px-3 py-1">
                            <img src="<?php echo e(asset('storage/'.$footerClub->logo_url)); ?>" alt="<?php echo e($footerClub->name); ?> logo" class="h-10 sm:h-12 w-auto" />
                        </div>
                    </div>
                    <div class="justify-self-end"></div>
                </div>
            </div>
        <?php endif; ?>
    </body>
</html>
<?php /**PATH /Users/corneliusvanmollendorf/CascadeProjects/windsurf-project/resources/views/layouts/app.blade.php ENDPATH**/ ?>