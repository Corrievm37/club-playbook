<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto p-6">
        <h1 class="text-2xl font-semibold mb-4">Super Admin Dashboard</h1>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div class="bg-white p-4 shadow rounded">
                <div class="text-sm text-gray-600">Clubs</div>
                <div class="text-2xl font-bold"><?php echo e($stats['clubs']); ?></div>
            </div>
            <div class="bg-white p-4 shadow rounded">
                <div class="text-sm text-gray-600">Users</div>
                <div class="text-2xl font-bold"><?php echo e($stats['users']); ?></div>
            </div>
            <div class="bg-white p-4 shadow rounded">
                <div class="text-sm text-gray-600">Pending Registrations</div>
                <div class="text-2xl font-bold"><?php echo e($stats['registrations_pending']); ?></div>
            </div>
            <div class="bg-white p-4 shadow rounded">
                <div class="text-sm text-gray-600">Overdue Invoices</div>
                <div class="text-2xl font-bold"><?php echo e($stats['invoices_overdue']); ?></div>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div class="bg-white p-4 shadow rounded">
                <h2 class="text-lg font-semibold mb-2">Recent Clubs</h2>
                <ul class="list-disc pl-5">
                    <?php $__currentLoopData = $recentClubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($c->name); ?> (<?php echo e($c->slug); ?>)</li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="bg-white p-4 shadow rounded">
                <h2 class="text-lg font-semibold mb-2">Recent Registrations</h2>
                <ul class="list-disc pl-5">
                    <?php $__currentLoopData = $recentPlayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($p->last_name); ?>, <?php echo e($p->first_name); ?> - <?php echo e($p->age_group); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/corneliusvanmollendorf/CascadeProjects/windsurf-project/resources/views/superadmin/dashboard.blade.php ENDPATH**/ ?>