<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto p-6">
    <h1 class="text-2xl font-semibold mb-4">My Invoices</h1>
    <?php if(session('status')): ?>
        <div class="bg-green-100 text-green-800 p-3 mb-4 rounded"><?php echo e(session('status')); ?></div>
    <?php endif; ?>
    <div class="overflow-x-auto bg-white shadow rounded">
        <table class="min-w-full text-sm">
            <thead>
                <tr class="border-b bg-gray-50 text-left">
                    <th class="p-3">Invoice</th>
                    <th class="p-3">Player</th>
                    <th class="p-3">Amount</th>
                    <th class="p-3">Due</th>
                    <th class="p-3">Status</th>
                    <th class="p-3"></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-b">
                    <td class="p-3"><?php echo e($inv->number); ?></td>
                    <td class="p-3"><?php echo e(optional($inv->player)->first_name); ?> <?php echo e(optional($inv->player)->last_name); ?></td>
                    <td class="p-3">ZAR <?php echo e(number_format($inv->total_cents/100, 2)); ?></td>
                    <td class="p-3"><?php echo e($inv->due_date); ?></td>
                    <td class="p-3"><?php echo e(strtoupper($inv->status)); ?></td>
                    <td class="p-3">
                        <a href="<?php echo e(route('guardian.invoices.show', $inv->id)); ?>" class="text-blue-700">View</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td class="p-4 text-center text-gray-600" colspan="6">No invoices found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="mt-4"><?php echo e($invoices->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/corneliusvanmollendorf/CascadeProjects/windsurf-project/resources/views/guardian/invoices/index.blade.php ENDPATH**/ ?>