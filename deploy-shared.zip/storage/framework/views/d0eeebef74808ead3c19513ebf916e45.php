<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Invoice <?php echo e($invoice->number); ?></title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 12px; color: #111; }
        .row { display: flex; justify-content: space-between; align-items: flex-start; }
        .mb-2 { margin-bottom: 12px; }
        .mb-4 { margin-bottom: 24px; }
        .text-right { text-align: right; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; }
        th { background: #f5f5f5; }
        .badge { display: inline-block; padding: 2px 6px; border-radius: 4px; font-size: 11px; }
        .badge-paid { background: #d1fae5; color: #065f46; }
        .badge-partial { background: #fef3c7; color: #92400e; }
        .badge-overdue { background: #fee2e2; color: #991b1b; }
        .badge-default { background: #e5e7eb; color: #111827; }
    </style>
</head>
<body>
    <div class="row mb-4">
        <div>
            <div style="display:flex; align-items:center; gap:10px;">
                <?php if(!empty($club->logo_url)): ?>
                    <img src="<?php echo e(public_path('storage/'.$club->logo_url)); ?>" alt="<?php echo e($club->name); ?> logo" style="height:48px; width:auto;" />
                <?php endif; ?>
                <h2 style="margin:0;"><?php echo e($club->name); ?></h2>
            </div>
            <div><?php echo e($club->address_line1); ?></div>
            <div><?php echo e($club->city); ?> <?php echo e($club->postal_code); ?></div>
            <div>Tel: <?php echo e($club->phone); ?></div>
            <div>Email: <?php echo e($club->email); ?></div>
        </div>
        <div class="text-right">
            <h3 style="margin:0;">Invoice</h3>
            <div><strong>No:</strong> <?php echo e($invoice->number); ?></div>
            <div><strong>Date:</strong> <?php echo e($invoice->issue_date); ?></div>
            <div><strong>Due:</strong> <?php echo e($invoice->due_date ?? '—'); ?></div>
            <?php ($paidCents = (int) ($invoice->payments?->sum('amount_cents') ?? 0)); ?>
            <?php ($badgeClass = 'badge-default'); ?>
            <?php ($badgeText = strtoupper($invoice->status)); ?>
            <?php if($invoice->status === 'paid'): ?>
                <?php ($badgeClass = 'badge-paid'); ?>
                <?php ($badgeText = 'PAID'); ?>
            <?php elseif($paidCents > 0 && (int)$invoice->balance_cents > 0): ?>
                <?php ($badgeClass = 'badge-partial'); ?>
                <?php ($badgeText = 'PARTIALLY PAID'); ?>
            <?php elseif($invoice->status === 'overdue'): ?>
                <?php ($badgeClass = 'badge-overdue'); ?>
                <?php ($badgeText = 'OVERDUE'); ?>
            <?php endif; ?>
            <div><strong>Status:</strong> <span class="badge <?php echo e($badgeClass); ?>"><?php echo e($badgeText); ?></span></div>
        </div>
    </div>

    <div class="mb-4">
        <strong>Billed To:</strong>
        <div><?php echo e(optional($invoice->player)->first_name); ?> <?php echo e(optional($invoice->player)->last_name); ?></div>
        <div>Age Group: <?php echo e(optional($invoice->player)->age_group); ?></div>
    </div>

    <table class="mb-4">
        <thead>
            <tr>
                <th>Description</th>
                <th class="text-right">Amount (ZAR)</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e(optional($invoice->fee)->name ?? 'Club Fees'); ?></td>
                <td class="text-right"><?php echo e(number_format(($invoice->subtotal_cents)/100, 2)); ?></td>
            </tr>
            <tr>
                <td>Tax</td>
                <td class="text-right"><?php echo e(number_format(($invoice->tax_cents)/100, 2)); ?></td>
            </tr>
            <tr>
                <td><strong>Total</strong></td>
                <td class="text-right"><strong><?php echo e(number_format(($invoice->total_cents)/100, 2)); ?></strong></td>
            </tr>
            <tr>
                <td>Paid to date</td>
                <td class="text-right"><?php echo e(number_format(($paidCents)/100, 2)); ?></td>
            </tr>
            <tr>
                <td>Balance</td>
                <td class="text-right"><?php echo e(number_format(($invoice->balance_cents)/100, 2)); ?></td>
            </tr>
        </tbody>
    </table>

    <div class="mb-2"><strong>Payments</strong></div>
    <table class="mb-4">
        <thead>
            <tr>
                <th>Date</th>
                <th>Method</th>
                <th>Reference</th>
                <th class="text-right">Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $invoice->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($p->paid_at); ?></td>
                <td><?php echo e(strtoupper($p->method)); ?></td>
                <td><?php echo e($p->reference); ?></td>
                <td class="text-right"><?php echo e(number_format(($p->amount_cents)/100, 2)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4" class="text-right">No payments recorded.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="mb-2"><strong>Payment Details</strong></div>
    <div>Account Name: <?php echo e($club->bank_account_name); ?></div>
    <div>Bank: <?php echo e($club->bank_name); ?></div>
    <div>Account Number: <?php echo e($club->bank_account_number); ?></div>
    <div>Branch Code: <?php echo e($club->bank_branch_code); ?></div>
    <div>Reference: <?php echo e($invoice->number); ?></div>
    <?php if($club->vat_number): ?>
    <div>VAT Number: <?php echo e($club->vat_number); ?></div>
    <?php endif; ?>
</body>
</html>
<?php /**PATH /Users/corneliusvanmollendorf/CascadeProjects/windsurf-project/resources/views/pdf/invoice.blade.php ENDPATH**/ ?>