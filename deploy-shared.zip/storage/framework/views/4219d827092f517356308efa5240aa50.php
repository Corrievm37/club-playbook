<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <h1 class="text-2xl font-semibold mb-4">Edit Fee</h1>

    <form method="POST" action="<?php echo e(route('admin.fees.update', $fee->id)); ?>" class="space-y-6">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium">Season Year</label>
                <input type="number" name="season_year" value="<?php echo e(old('season_year', $fee->season_year)); ?>" class="mt-1 w-full border rounded p-2" required />
                <?php $__errorArgs = ['season_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label class="block text-sm font-medium">Name</label>
                <input type="text" name="name" value="<?php echo e(old('name', $fee->name)); ?>" class="mt-1 w-full border rounded p-2" required />
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label class="block text-sm font-medium">Amount (ZAR cents)</label>
                <input type="number" name="amount_cents" value="<?php echo e(old('amount_cents', $fee->amount_cents)); ?>" class="mt-1 w-full border rounded p-2" required />
                <?php $__errorArgs = ['amount_cents'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label class="block text-sm font-medium">Due Date</label>
                <input type="date" name="due_date" value="<?php echo e(old('due_date', optional($fee->due_date)->format('Y-m-d'))); ?>" class="mt-1 w-full border rounded p-2" />
                <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="md:col-span-2">
                <label class="inline-flex items-center">
                    <input type="checkbox" name="active" value="1" class="mr-2" <?php echo e(old('active', $fee->active) ? 'checked' : ''); ?> /> Active
                </label>
            </div>
        </div>
        <div class="mt-6">
            <button type="submit" class="bg-blue-700 hover:bg-blue-800 text-white font-bold px-6 py-3 rounded shadow-lg focus:outline-none focus:ring-2 focus:ring-blue-400 border border-blue-800">Save</button>
            <a href="<?php echo e(route('admin.fees.index')); ?>" class="ml-2">Cancel</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/corneliusvanmollendorf/CascadeProjects/windsurf-project/resources/views/admin/fees/edit.blade.php ENDPATH**/ ?>