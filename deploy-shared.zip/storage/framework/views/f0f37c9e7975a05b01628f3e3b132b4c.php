<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <?php if(session('status')): ?>
        <div class="bg-green-100 text-green-800 p-3 mb-4 rounded"><?php echo e(session('status')); ?></div>
    <?php endif; ?>

    <div class="flex items-center justify-between mb-4">
        <h1 class="text-2xl font-semibold">Invoices</h1>
        <a href="<?php echo e(route('admin.invoices.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded">New Invoice</a>
    </div>

    <div class="overflow-x-auto">
        <table class="min-w-full border">
            <thead>
                <tr class="bg-gray-100">
                    <th class="p-2 border">Number</th>
                    <th class="p-2 border">Player</th>
                    <th class="p-2 border">Fee</th>
                    <th class="p-2 border">Issue</th>
                    <th class="p-2 border">Due</th>
                    <th class="p-2 border text-right">Total</th>
                    <th class="p-2 border text-right">Balance</th>
                    <th class="p-2 border">Status</th>
                    <th class="p-2 border">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="p-2 border"><?php echo e($inv->number); ?></td>
                    <td class="p-2 border"><?php echo e(optional($inv->player)->first_name); ?> <?php echo e(optional($inv->player)->last_name); ?></td>
                    <td class="p-2 border"><?php echo e(optional($inv->fee)->name); ?></td>
                    <td class="p-2 border"><?php echo e($inv->issue_date); ?></td>
                    <td class="p-2 border"><?php echo e($inv->due_date); ?></td>
                    <td class="p-2 border text-right"><?php echo e(number_format($inv->total_cents/100, 2)); ?></td>
                    <td class="p-2 border text-right"><?php echo e(number_format($inv->balance_cents/100, 2)); ?></td>
                    <td class="p-2 border"><?php echo e(strtoupper($inv->status)); ?></td>
                    <td class="p-2 border space-x-2">
                        <a class="text-blue-600" href="<?php echo e(route('admin.invoices.show', $inv->id)); ?>">View</a>
                        <a class="text-green-700" href="<?php echo e(route('invoices.pdf', $inv->id)); ?>">PDF</a>
                        <form method="POST" action="<?php echo e(route('admin.invoices.destroy', $inv->id)); ?>" class="inline" onsubmit="return confirm('Delete invoice?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="text-red-600">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td class="p-4 text-center" colspan="9">No invoices found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4"><?php echo e($invoices->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/corneliusvanmollendorf/CascadeProjects/windsurf-project/resources/views/admin/invoices/index.blade.php ENDPATH**/ ?>