<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto p-6">
        <?php if(session('status')): ?>
            <div class="bg-green-100 text-green-800 p-3 mb-4 rounded"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <div class="flex items-center justify-between mb-4">
            <h1 class="text-2xl font-semibold">Clubs</h1>
            <a href="<?php echo e(route('admin.clubs.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded">New Club</a>
        </div>

        <div class="overflow-x-auto">
            <table class="min-w-full border">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="p-2 border text-left">Name</th>
                        <th class="p-2 border text-left">Slug</th>
                        <th class="p-2 border text-left">Email</th>
                        <th class="p-2 border text-left">Phone</th>
                        <th class="p-2 border">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="p-2 border"><?php echo e($club->name); ?></td>
                        <td class="p-2 border"><?php echo e($club->slug); ?></td>
                        <td class="p-2 border"><?php echo e($club->email); ?></td>
                        <td class="p-2 border"><?php echo e($club->phone); ?></td>
                        <td class="p-2 border space-x-2 whitespace-nowrap">
                            <a href="<?php echo e(route('admin.clubs.edit', $club->id)); ?>" class="text-blue-600 underline">Edit</a>
                            <a href="<?php echo e(url('/register/'.$club->slug.'/player')); ?>" target="_blank" class="text-green-700 underline">Registration Link</a>
                            <form method="POST" action="<?php echo e(route('admin.active-club.set')); ?>" class="inline">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="club_id" value="<?php echo e($club->id); ?>" />
                                <button type="submit" class="bg-blue-100 hover:bg-blue-200 text-blue-800 px-2 py-1 rounded text-xs">Set Active</button>
                            </form>
                            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'org_admin')): ?>
                            <form method="POST" action="<?php echo e(route('superadmin.impersonate.start', $club->id)); ?>" class="inline" onsubmit="return confirm('Impersonate <?php echo e($club->name); ?>?');">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="bg-yellow-100 hover:bg-yellow-200 text-yellow-800 px-2 py-1 rounded text-xs">Impersonate</button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="p-4 text-center">No clubs found.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-4"><?php echo e($clubs->links()); ?></div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/corneliusvanmollendorf/CascadeProjects/windsurf-project/resources/views/admin/clubs/index.blade.php ENDPATH**/ ?>