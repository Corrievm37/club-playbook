<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto p-6 max-w-3xl">
        <h1 class="text-2xl font-semibold mb-4">Player Registration <?php if($club): ?> - <?php echo e($club->name); ?> <?php endif; ?></h1>

        <form action="<?php echo e(route('registration.store', ['club' => $club->slug])); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium">Player First Name</label>
                    <input type="text" name="first_name" value="<?php echo e(old('first_name')); ?>" class="mt-1 w-full border rounded p-2" required />
                    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label class="block text-sm font-medium">Player Last Name</label>
                    <input type="text" name="last_name" value="<?php echo e(old('last_name')); ?>" class="mt-1 w-full border rounded p-2" required />
                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label class="block text-sm font-medium">Date of Birth</label>
                    <input type="date" name="dob" value="<?php echo e(old('dob')); ?>" class="mt-1 w-full border rounded p-2" required />
                    <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label class="block text-sm font-medium">Gender</label>
                    <select name="gender" class="mt-1 w-full border rounded p-2">
                        <option value="">Prefer not to say</option>
                        <option value="male" <?php echo e(old('gender')==='male'?'selected':''); ?>>Male</option>
                        <option value="female" <?php echo e(old('gender')==='female'?'selected':''); ?>>Female</option>
                        <option value="other" <?php echo e(old('gender')==='other'?'selected':''); ?>>Other</option>
                    </select>
                    <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label class="block text-sm font-medium">South African ID Number</label>
                    <input id="sa_id_number" type="text" name="sa_id_number" value="<?php echo e(old('sa_id_number')); ?>" class="mt-1 w-full border rounded p-2" placeholder="13 digits" inputmode="numeric" autocomplete="off" />
                    <div id="sa_id_error" class="text-red-600 text-sm mt-1 hidden">Invalid South African ID number.</div>
                    <?php $__errorArgs = ['sa_id_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label class="block text-sm font-medium">School Name</label>
                    <input type="text" name="school_name" value="<?php echo e(old('school_name')); ?>" class="mt-1 w-full border rounded p-2" />
                    <?php $__errorArgs = ['school_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <h2 class="text-xl font-semibold">Guardian Details</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium">First Name</label>
                    <input type="text" name="guardian_first_name" value="<?php echo e(old('guardian_first_name')); ?>" class="mt-1 w-full border rounded p-2" required />
                    <?php $__errorArgs = ['guardian_first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label class="block text-sm font-medium">Last Name</label>
                    <input type="text" name="guardian_last_name" value="<?php echo e(old('guardian_last_name')); ?>" class="mt-1 w-full border rounded p-2" required />
                    <?php $__errorArgs = ['guardian_last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label class="block text-sm font-medium">Email</label>
                    <input type="email" name="guardian_email" value="<?php echo e(old('guardian_email')); ?>" class="mt-1 w-full border rounded p-2" />
                    <?php $__errorArgs = ['guardian_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label class="block text-sm font-medium">Phone</label>
                    <input type="text" name="guardian_phone" value="<?php echo e(old('guardian_phone')); ?>" class="mt-1 w-full border rounded p-2" />
                    <?php $__errorArgs = ['guardian_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="mt-2">
                <label class="inline-flex items-center">
                    <input type="checkbox" name="consent_guardian" value="1" class="mr-2" required /> I am the parent/guardian and consent to processing this registration.
                </label>
                <?php $__errorArgs = ['consent_guardian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mt-6">
                <button id="submit_registration" type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Submit Registration</button>
            </div>
        </form>
    </div>
    <script>
        (function(){
            const input = document.getElementById('sa_id_number');
            const error = document.getElementById('sa_id_error');
            const submit = document.getElementById('submit_registration');
            function digitsOnly(s){return (s||'').replace(/\D+/g,'');}
            function luhnCheck(num){
                let sum=0, alt=false;
                for(let i=num.length-1;i>=0;i--){
                    let n=parseInt(num[i],10);
                    if(alt){n*=2;if(n>9)n-=9}
                    sum+=n;alt=!alt;
                }
                return sum%10===0;
            }
            function validate(){
                const v=digitsOnly(input.value);
                const ok=(v.length===13)&&luhnCheck(v);
                if(v.length===0){
                    error.classList.add('hidden');
                    submit.disabled=false;
                    submit.classList.remove('opacity-50','cursor-not-allowed');
                    return;
                }
                if(!ok){
                    error.classList.remove('hidden');
                    submit.disabled=true;
                    submit.classList.add('opacity-50','cursor-not-allowed');
                }else{
                    error.classList.add('hidden');
                    submit.disabled=false;
                    submit.classList.remove('opacity-50','cursor-not-allowed');
                }
            }
            input.addEventListener('input', validate);
            validate();
        })();
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/corneliusvanmollendorf/CascadeProjects/windsurf-project/resources/views/registration/player.blade.php ENDPATH**/ ?>