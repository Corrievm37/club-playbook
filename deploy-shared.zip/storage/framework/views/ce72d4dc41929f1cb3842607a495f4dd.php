<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto p-6">
    <?php if(session('status')): ?>
        <div class="bg-green-100 text-green-800 p-3 mb-4 rounded"><?php echo e(session('status')); ?></div>
    <?php endif; ?>

    <h1 class="text-2xl font-semibold mb-4">Invoice <?php echo e($invoice->number); ?></h1>

    <div class="bg-white shadow rounded p-4 mb-6">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <div><strong>Player:</strong> <?php echo e(optional($invoice->player)->first_name); ?> <?php echo e(optional($invoice->player)->last_name); ?></div>
                <div><strong>Fee:</strong> <?php echo e(optional($invoice->fee)->name); ?></div>
                <div><strong>Issue:</strong> <?php echo e($invoice->issue_date); ?> | <strong>Due:</strong> <?php echo e($invoice->due_date); ?></div>
            </div>
            <div class="text-right">
                <div><strong>Total:</strong> ZAR <?php echo e(number_format($invoice->total_cents/100, 2)); ?></div>
                <div><strong>Balance:</strong> ZAR <?php echo e(number_format($invoice->balance_cents/100, 2)); ?></div>
                <div><strong>Status:</strong> <?php echo e(strtoupper($invoice->status)); ?></div>
            </div>
        </div>
    </div>

    <div class="bg-white shadow rounded p-4">
        <h2 class="text-lg font-semibold mb-2">Proof of Payment</h2>
        <?php if($invoice->proof_path): ?>
            <p class="mb-2">You have uploaded a proof of payment. You can view it here:</p>
            <a class="text-blue-700 underline" target="_blank" href="<?php echo e(asset('storage/'.$invoice->proof_path)); ?>">View uploaded proof</a>
            <p class="text-sm text-gray-600 mt-2">Status: <?php echo e(strtoupper($invoice->status)); ?>. A manager will review and confirm it.</p>
        <?php elseif($invoice->status !== 'paid'): ?>
            <form method="POST" action="<?php echo e(route('guardian.invoices.upload_proof', $invoice->id)); ?>" enctype="multipart/form-data" class="space-y-3">
                <?php echo csrf_field(); ?>
                <div>
                    <label class="block text-sm font-medium">Upload Proof (PDF/JPG/PNG, max 8MB)</label>
                    <input type="file" name="proof" accept=".pdf,.jpg,.jpeg,.png" class="mt-1 w-full border rounded p-2" required>
                    <?php $__errorArgs = ['proof'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Submit Proof</button>
            </form>
        <?php else: ?>
            <p class="text-sm text-gray-700">This invoice is fully paid.</p>
        <?php endif; ?>
    </div>

    <div class="mt-6">
        <a href="<?php echo e(route('guardian.invoices.index')); ?>" class="text-gray-700">Back to invoices</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/corneliusvanmollendorf/CascadeProjects/windsurf-project/resources/views/guardian/invoices/show.blade.php ENDPATH**/ ?>