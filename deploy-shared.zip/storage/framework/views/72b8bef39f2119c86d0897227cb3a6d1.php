<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto p-6 max-w-4xl">
        <?php if(session('status')): ?>
            <div class="bg-green-100 text-green-800 p-3 mb-4 rounded"><?php echo e(session('status')); ?></div>
        <?php endif; ?>
        <h1 class="text-2xl font-semibold mb-4">Upcoming Sessions</h1>
        <div class="overflow-x-auto">
            <table class="min-w-full border">
                <thead>
                <tr class="bg-gray-100">
                    <th class="p-2 border text-left">When</th>
                    <th class="p-2 border text-left">Type</th>
                    <th class="p-2 border text-left">Player</th>
                    <th class="p-2 border text-left">RSVP</th>
                    <th class="p-2 border text-left">Location</th>
                    <th class="p-2 border text-left">Notes</th>
                    <th class="p-2 border">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="p-2 border"><?php echo e($rec->session->scheduled_at->format('Y-m-d H:i')); ?></td>
                        <td class="p-2 border"><?php echo e(ucfirst($rec->session->type)); ?></td>
                        <td class="p-2 border"><?php echo e($rec->player->last_name); ?>, <?php echo e($rec->player->first_name); ?></td>
                        <td class="p-2 border">
                            <form method="POST" action="<?php echo e(route('guardian.vote', $rec->id)); ?>" class="inline-flex items-center space-x-2">
                                <?php echo csrf_field(); ?>
                                <select name="rsvp_status" class="border rounded p-1 text-sm">
                                    <?php $__currentLoopData = ['unknown'=>'Unknown','yes'=>'Yes','no'=>'No','maybe'=>'Maybe']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($val); ?>" <?php echo e($rec->rsvp_status===$val?'selected':''); ?>><?php echo e($label); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button class="px-2 py-1 text-xs bg-blue-600 text-white rounded">Save</button>
                            </form>
                        </td>
                        <td class="p-2 border"><?php echo e($rec->session->location ?? '—'); ?></td>
                        <td class="p-2 border"><?php echo e($rec->session->notes ?? '—'); ?></td>
                        <td class="p-2 border text-center">
                            <span class="text-gray-400">—</span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="p-4 text-center">No upcoming sessions.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/corneliusvanmollendorf/CascadeProjects/windsurf-project/resources/views/guardian/sessions/index.blade.php ENDPATH**/ ?>