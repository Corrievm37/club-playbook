<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto p-6">
        <?php if(session('status')): ?>
            <div class="bg-green-100 text-green-800 p-3 mb-4 rounded"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <div class="flex items-center justify-between mb-4">
            <h1 class="text-2xl font-semibold">Players (<?php echo e(ucfirst($status)); ?>) <?php if($club): ?> - <?php echo e($club->name); ?> <?php endif; ?></h1>
            <div class="space-x-2">
                <a class="px-3 py-2 border rounded <?php echo e($status==='pending'?'bg-gray-200':''); ?>" href="<?php echo e(route('admin.players.index', ['status' => 'pending'])); ?>">Pending</a>
                <a class="px-3 py-2 border rounded <?php echo e($status==='approved'?'bg-gray-200':''); ?>" href="<?php echo e(route('admin.players.index', ['status' => 'approved'])); ?>">Approved</a>
                <a class="px-3 py-2 border rounded <?php echo e($status==='rejected'?'bg-gray-200':''); ?>" href="<?php echo e(route('admin.players.index', ['status' => 'rejected'])); ?>">Rejected</a>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="min-w-full border">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="p-2 border text-left">Name</th>
                        <th class="p-2 border text-left">DOB</th>
                        <th class="p-2 border text-left">Age Group</th>
                        <th class="p-2 border text-left">Season</th>
                        <th class="p-2 border text-left">Shirt Size</th>
                        <th class="p-2 border text-left">Shirt Handed Out</th>
                        <th class="p-2 border text-left">Documents</th>
                        <th class="p-2 border text-left">Status</th>
                        <th class="p-2 border text-left">Rejection Reason</th>
                        <th class="p-2 border">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr x-data="{ openReject:false, openViewReason:false }">
                        <td class="p-2 border"><?php echo e($player->last_name); ?>, <?php echo e($player->first_name); ?></td>
                        <td class="p-2 border"><?php echo e($player->dob); ?></td>
                        <td class="p-2 border"><?php echo e($player->age_group); ?></td>
                        <td class="p-2 border"><?php echo e($player->season_year); ?></td>
                        <td class="p-2 border"><?php echo e($player->shirt_size ?? '—'); ?></td>
                        <td class="p-2 border">
                            <?php if($player->shirt_handed_out): ?>
                                <span class="inline-block text-green-800 bg-green-100 px-2 py-0.5 rounded text-xs">Yes</span>
                            <?php else: ?>
                                <span class="inline-block text-gray-700 bg-gray-100 px-2 py-0.5 rounded text-xs">No</span>
                            <?php endif; ?>
                        </td>
                        <td class="p-2 border space-x-2">
                            <?php if(!empty($player->id_document_path)): ?>
                                <a href="<?php echo e(asset('storage/'.$player->id_document_path)); ?>" target="_blank" class="text-blue-700 underline">ID Doc</a>
                            <?php endif; ?>
                            <?php if(!empty($player->medical_aid_card_path)): ?>
                                <a href="<?php echo e(asset('storage/'.$player->medical_aid_card_path)); ?>" target="_blank" class="text-blue-700 underline">Medical Card</a>
                            <?php endif; ?>
                            <?php if(empty($player->id_document_path) && empty($player->medical_aid_card_path)): ?>
                                <span class="text-gray-400">—</span>
                            <?php endif; ?>
                        </td>
                        <td class="p-2 border"><?php echo e(ucfirst($player->status)); ?></td>
                        <td class="p-2 border">
                            <?php if($player->status==='rejected' && $player->rejection_reason): ?>
                                <button type="button" class="text-blue-700 underline" @click="openViewReason=!openViewReason">View</button>
                                <div x-show="openViewReason" x-cloak class="mt-2 border rounded p-2 bg-blue-50 text-sm whitespace-pre-wrap">
                                    <?php echo e($player->rejection_reason); ?>

                                    <div class="text-right mt-1">
                                        <button type="button" class="text-xs underline" @click="openViewReason=false">Close</button>
                                    </div>
                                </div>
                            <?php else: ?>
                                <span class="text-gray-400">—</span>
                            <?php endif; ?>
                        </td>
                        <td class="p-2 border">
                            <?php if($player->status==='pending' || $player->status==='rejected'): ?>
                                <form method="POST" action="<?php echo e(route('admin.players.approve', $player->id)); ?>" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <button class="bg-green-700 hover:bg-green-800 text-white font-bold px-4 py-2 rounded shadow focus:outline-none focus:ring-2 focus:ring-green-300" onclick="return confirm('Approve this player?')">Approve</button>
                                </form>
                            <?php endif; ?>

                            <?php if($player->status==='pending' || $player->status==='approved'): ?>
                                <button type="button" class="bg-red-600 hover:bg-red-700 text-white font-semibold px-3 py-1.5 rounded shadow mt-2" @click="openReject=!openReject">Reject</button>
                                <div x-show="openReject" x-cloak class="mt-2 border rounded p-2 bg-red-50">
                                    <form method="POST" action="<?php echo e(route('admin.players.reject', $player->id)); ?>" class="space-y-2">
                                        <?php echo csrf_field(); ?>
                                        <textarea name="reason" class="w-full border rounded p-2 text-sm" rows="3" placeholder="Reason (required)" required></textarea>
                                        <div class="flex items-center justify-end space-x-2">
                                            <button type="button" class="px-3 py-1.5 rounded border" @click="openReject=false">Cancel</button>
                                            <button type="submit" class="bg-red-600 hover:bg-red-700 text-white font-semibold px-3 py-1.5 rounded shadow">Confirm Reject</button>
                                        </div>
                                    </form>
                                </div>
                            <?php endif; ?>

                            <?php if(!$player->shirt_handed_out): ?>
                                <form method="POST" action="<?php echo e(route('admin.players.shirt_handed_out', $player->id)); ?>" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <button class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-3 py-1.5 rounded shadow mt-2" onclick="return confirm('Mark shirt as handed out to this player?')">Mark Shirt Handed Out</button>
                                </form>
                            <?php else: ?>
                                <span class="ml-2 text-xs text-green-700">Shirt handed out</span>
                            <?php endif; ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" class="p-4 text-center">No players found.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-4"><?php echo e($players->links()); ?></div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/corneliusvanmollendorf/CascadeProjects/windsurf-project/resources/views/admin/players/index.blade.php ENDPATH**/ ?>