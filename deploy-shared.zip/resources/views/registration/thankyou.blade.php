<x-app-layout>
    <div class="container mx-auto p-12 text-center">
        <h1 class="text-2xl font-semibold mb-4">Thank you!</h1>
        <p>Your registration has been submitted and is pending club approval. You will be contacted if any further information is required.</p>
        <div class="mt-6">
            <a href="/" class="text-blue-600">Return to Home</a>
        </div>
    </div>
</x-app-layout>
