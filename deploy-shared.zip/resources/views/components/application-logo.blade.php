<img src="{{ asset('images/logo.png') }}" alt="{{ config('app.name') }}" {{ $attributes }}>
